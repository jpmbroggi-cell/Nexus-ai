from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from app.config import settings
from app.db import (init_db, add_message, get_history, get_memories, add_memory,
                    delete_memory, clear_history, get_preference, set_preference)
from app.personality import make_system_prompt
from app.ai import generate
from app.tools import run_tool

app = FastAPI(title="NEXUS AI", version="0.2.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=[x.strip() for x in settings.cors_origins.split(",") if x.strip()],
    allow_credentials=True, allow_methods=["GET", "POST", "PUT", "DELETE"],
    allow_headers=["*"])

@app.on_event("startup")
def startup():
    init_db()

class ChatIn(BaseModel):
    message: str = Field(min_length=1, max_length=12000)
class PersonalityIn(BaseModel):
    personality: str = Field(min_length=1, max_length=2000)
class ProviderIn(BaseModel):
    provider: str
class MemoryIn(BaseModel):
    content: str = Field(min_length=1, max_length=500)
class ToolIn(BaseModel):
    name: str
    text: str = Field(min_length=1, max_length=12000)

@app.get("/api/health")
def health():
    return {"status": "ok", "name": "NEXUS", "version": "0.2.0"}

@app.get("/api/settings")
def settings_read():
    return {
        "personality": get_preference("personality", "Amigável, inteligente e objetiva"),
        "provider": get_preference("provider", settings.ai_provider),
        "local_model": settings.ollama_model,
        "cloud_model_configured": bool(settings.ai_api_key and settings.ai_model)
    }

@app.put("/api/settings/personality")
def personality_write(data: PersonalityIn):
    set_preference("personality", data.personality)
    return {"ok": True}

@app.put("/api/settings/provider")
def provider_write(data: ProviderIn):
    if data.provider not in ("ollama", "cloud"):
        raise HTTPException(status_code=400, detail="Use 'ollama' ou 'cloud'.")
    if data.provider == "cloud" and not (settings.ai_api_key and settings.ai_model):
        raise HTTPException(status_code=400, detail="Configure AI_API_KEY e AI_MODEL no backend/.env.")
    set_preference("provider", data.provider)
    return {"ok": True, "provider": data.provider}

@app.get("/api/history")
def history_read():
    return get_history()

@app.delete("/api/history")
def history_clear():
    clear_history()
    return {"ok": True}

@app.post("/api/chat")
async def chat(data: ChatIn):
    user_text = data.message.strip()
    add_message("user", user_text)
    recent = get_history(24)
    prompt = make_system_prompt(
        get_preference("personality", "Amigável, inteligente e objetiva"),
        get_memories())
    conversation = [{"role": "system", "content": prompt}]
    conversation += [{"role": m["role"], "content": m["content"]} for m in recent]
    provider = get_preference("provider", settings.ai_provider)
    try:
        answer = await generate(conversation, provider)
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"Falha no motor {provider}: {type(exc).__name__}") from exc
    add_message("assistant", answer)
    return {"reply": answer, "provider": provider}

@app.get("/api/memories")
def memories_read():
    return {"memories": get_memories()}

@app.post("/api/memories")
def memories_create(data: MemoryIn):
    try:
        add_memory(data.content)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    return {"ok": True}

@app.delete("/api/memories/{memory_id}")
def memories_delete(memory_id: int):
    delete_memory(memory_id)
    return {"ok": True}

@app.post("/api/tools")
def tools_run(data: ToolIn):
    try:
        return {"result": run_tool(data.name, data.text)}
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
