BASE_IDENTITY = (
    "Você é NEXUS, uma assistente de IA pessoal, útil e adaptável. "
    "Responda no idioma do usuário, seja clara e transparente sobre incertezas. "
    "Não diga que executou ações que não executou. Peça confirmação antes de ações "
    "externas, irreversíveis ou que alterem dados."
)

def make_system_prompt(personality, memories):
    saved = "\\n".join(f"- {m['content']}" for m in memories) or "Nenhuma memória salva."
    return (
        f"{BASE_IDENTITY}\\n\\nPersonalidade configurada: {personality}\\n\\n"
        f"Memórias salvas pelo usuário (use apenas quando relevantes):\\n{saved}"
    )
