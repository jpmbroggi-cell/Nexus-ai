def run_tool(name: str, text: str):
    if name == "summarize":
        clean = text.strip()
        if not clean:
            raise ValueError("Digite um texto para resumir.")
        # Ferramenta de demonstração, sem chamar serviços externos.
        sentences = [s.strip() for s in clean.replace("!", ".").replace("?", ".").split(".") if s.strip()]
        return " ".join(sentences[:3])[:1200]
    if name == "checklist":
        lines = [line.strip(" -•\\t") for line in text.splitlines() if line.strip(" -•\\t")]
        if not lines:
            raise ValueError("Digite itens, um por linha.")
        return "\\n".join(f"☐ {line}" for line in lines[:30])
    raise ValueError("Ferramenta desconhecida.")
