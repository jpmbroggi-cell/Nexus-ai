import httpx
from app.config import settings

async def generate(messages, provider):
    if provider == "ollama":
        payload = {"model": settings.ollama_model, "messages": messages, "stream": False}
        async with httpx.AsyncClient(timeout=120) as client:
            response = await client.post(
                settings.ollama_base_url.rstrip("/") + "/api/chat", json=payload)
            response.raise_for_status()
            return response.json()["message"]["content"]

    if provider == "cloud":
        if not settings.ai_api_key or not settings.ai_model:
            raise RuntimeError("Configure AI_API_KEY e AI_MODEL no backend/.env.")
        headers = {"Authorization": f"Bearer {settings.ai_api_key}"}
        payload = {"model": settings.ai_model, "messages": messages}
        async with httpx.AsyncClient(timeout=120) as client:
            response = await client.post(
                settings.ai_base_url.rstrip("/") + "/chat/completions",
                headers=headers, json=payload)
            response.raise_for_status()
            return response.json()["choices"][0]["message"]["content"]

    raise ValueError("Provedor inválido.")
