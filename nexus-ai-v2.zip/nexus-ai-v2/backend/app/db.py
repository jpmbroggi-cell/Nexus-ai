import sqlite3
from pathlib import Path
from app.config import settings

def connect():
    path = Path(settings.database_path)
    if str(path.parent) not in ("", "."):
        path.parent.mkdir(parents=True, exist_ok=True)
    db = sqlite3.connect(path)
    db.row_factory = sqlite3.Row
    return db

def init_db():
    with connect() as db:
        db.execute("""CREATE TABLE IF NOT EXISTS messages(
            id INTEGER PRIMARY KEY AUTOINCREMENT, role TEXT NOT NULL,
            content TEXT NOT NULL, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)""")
        db.execute("""CREATE TABLE IF NOT EXISTS memories(
            id INTEGER PRIMARY KEY AUTOINCREMENT, content TEXT NOT NULL UNIQUE,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP)""")
        db.execute("""CREATE TABLE IF NOT EXISTS preferences(
            key TEXT PRIMARY KEY, value TEXT NOT NULL)""")
        db.execute("INSERT OR IGNORE INTO preferences VALUES('personality', ?)",
                   ("Amigável, inteligente e objetiva",))
        db.execute("INSERT OR IGNORE INTO preferences VALUES('provider', ?)",
                   (settings.ai_provider,))
        db.commit()

def add_message(role, content):
    with connect() as db:
        db.execute("INSERT INTO messages(role,content) VALUES(?,?)", (role, content))
        db.commit()

def get_history(limit=80):
    with connect() as db:
        rows = db.execute(
            "SELECT id,role,content,created_at FROM messages ORDER BY id DESC LIMIT ?",
            (limit,)).fetchall()
    return [dict(r) for r in reversed(rows)]

def clear_history():
    with connect() as db:
        db.execute("DELETE FROM messages")
        db.commit()

def get_memories():
    with connect() as db:
        return [dict(r) for r in db.execute(
            "SELECT id,content,created_at FROM memories ORDER BY id DESC").fetchall()]

def add_memory(content):
    clean = content.strip()
    if not clean or len(clean) > 500:
        raise ValueError("A memória deve ter entre 1 e 500 caracteres.")
    with connect() as db:
        db.execute("INSERT OR IGNORE INTO memories(content) VALUES(?)", (clean,))
        db.commit()

def delete_memory(memory_id):
    with connect() as db:
        db.execute("DELETE FROM memories WHERE id=?", (memory_id,))
        db.commit()

def get_preference(key, default=""):
    with connect() as db:
        row = db.execute("SELECT value FROM preferences WHERE key=?", (key,)).fetchone()
    return row["value"] if row else default

def set_preference(key, value):
    with connect() as db:
        db.execute(
            "INSERT INTO preferences(key,value) VALUES(?,?) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, value))
        db.commit()
