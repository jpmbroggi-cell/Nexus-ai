# NEXUS AI — versão 0.2

Aplicação web local com:
- Chat React + Vite
- Backend FastAPI
- Memória persistente SQLite, com criação e exclusão manual
- Personalidade editável
- Seleção entre Ollama local e API compatível com OpenAI
- Ferramentas locais seguras para resumir texto e criar listas de tarefas

## Requisitos
- Python 3.11+
- Node.js 20+
- Ollama (para modelo local) ou uma chave de API (para provedor em nuvem)

## 1. Configurar o backend
```bash
cd backend
python -m venv .venv
# Windows PowerShell: .venv\\Scripts\\Activate.ps1
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
```

Edite `backend/.env`:
- Local: `AI_PROVIDER=ollama`, `OLLAMA_MODEL=llama3.2`
- API: `AI_PROVIDER=cloud`, `AI_API_KEY=sua-chave`, `AI_MODEL=nome-do-modelo`
- `AI_BASE_URL` deve ser a URL base compatível com `/chat/completions`.

Para Ollama, instale-o e execute:
```bash
ollama pull llama3.2
ollama serve
```

Inicie o backend:
```bash
uvicorn app.main:app --reload
```
API: http://localhost:8000 — documentação: http://localhost:8000/docs

## 2. Configurar o frontend
Em outro terminal:
```bash
cd frontend
npm install
npm run dev
```
Abra http://localhost:5173.

## Segurança e limites
- Chaves de API ficam somente no backend, em `.env`.
- A seleção do provedor na interface não expõe segredos.
- Ferramentas incluídas trabalham apenas com texto fornecido pelo usuário; não executam comandos arbitrários nem ações externas.
- Antes de publicar, implemente autenticação, HTTPS, limites de requisição, CORS restrito e armazenamento seguro de segredos.
- A memória é local, em SQLite, e pode ser apagada pela interface.

Este projeto é um ponto de partida executável em ambiente local; não é um serviço hospedado na internet.
